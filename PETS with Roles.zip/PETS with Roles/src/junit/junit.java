package junit;



import static org.junit.Assert.assertEquals;

import org.junit.Test;


import junit.*;

public class junit {

    @Test
    public void test1() {
        methods tester = new methods(); // MyClass is tested

        // assert statements
        assertEquals("Name is already present in DataBase!", tester.insertDBlifecycle("pursharth","student"));
       
    }
    @Test
    public void test2() {
        methods tester = new methods(); // MyClass is tested

        // assert statements
       
        assertEquals("data updated successfully in life cycle", tester.insertDBlifecycle("vnaiycg12we","intbhern"));
    }
}